#include "Button.h"

Button::Button(int pin) {
  // Use 'this->' to make the difference between the
  // 'pin' attribute of the class and the 
  // local variable 'pin' created from the parameter.
  this->pin = pin;
  init();
}

void Button::init() {
  pinMode(pin, INPUT);
  // Always try to avoid duplicate code.
  // Instead of writing digitalWrite(pin, LOW) here,
  // call the function off() which already does that
  state = BUTTON_OFF;
}

void Button::toggle() {
  if (digitalRead(pin) == HIGH){
    if(flag == 0){
      flag = 1;
      state = !state;
    }
  } else {
    if(flag == 1){
      flag = 0;
    }
  }
}

void Button::on() {
  state = 1;
}

void Button::off() {
  state = 0;
}

boolean Button::getState() {
  return state;
}
