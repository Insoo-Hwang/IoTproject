#include "Ultrasonic.h"

Ultrasonic::Ultrasonic(int trigPin, int echoPin) {
  // Use 'this->' to make the difference between the
  // 'pin' attribute of the class and the
  // local variable 'pin' created from the parameter.
  this->trigPin = trigPin;
  this->echoPin = echoPin;
  init();
}
void Ultrasonic::init() {
  pinMode(trigPin, OUTPUT);
  pinMode(echoPin, INPUT);
  distance = 1;
}

float Ultrasonic::getDistance() {
  digitalWrite(trigPin, LOW);
  delayMicroseconds(2);
  digitalWrite(trigPin, HIGH);
  delayMicroseconds(10);
  digitalWrite(trigPin, LOW);
  distance = pulseIn(echoPin, HIGH)/29/2;
  return distance;
}
