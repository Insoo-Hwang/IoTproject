#include <Arduino.h>

#define LED_OFF 0
#define LED_ON 1

class Led {
  private:
    int pin;
    boolean state;

  public:
    Led(int pin);
    void init();
    void on();
    void off();
    void setState(boolean s);
    boolean getState();
};
