#include <Arduino.h>

#define BUTTON_OFF 0
#define BUTTON_ON 1

class Button {
  private:
    int pin;
    boolean state;
    int flag;

  public:
    Button(int pin);
    void init();
    void toggle();
    void on();
    void off();
    boolean getState();
};
