#include <Arduino.h>

class Ultrasonic {
  private:
    int trigPin;
    int echoPin;
    float distance;

  public:
    Ultrasonic(int trigPin, int echoPin);
    void init();
    float getDistance();
};
